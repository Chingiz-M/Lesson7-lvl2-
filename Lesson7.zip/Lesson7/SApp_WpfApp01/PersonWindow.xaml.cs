﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SApp_WpfApp01
{
    /// <summary>
    /// Interaction logic for PersonalWindow.xaml
    /// </summary>
    public partial class PersonWindow : Window
    {
        public static string ConnectDB = ConfigurationManager.ConnectionStrings["ConnectDB"].ConnectionString;
        SqlConnection connection;
        SqlDataAdapter adapter;
        public static DataTable dt;
        public PersonWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            connection = new SqlConnection(ConnectDB);
            adapter = new SqlDataAdapter("SELECT *  FROM [Work].[dbo].[Persons]", connection);
            dt = new DataTable();
            adapter.Fill(dt);

            peopleDataGrid.DataContext = dt.DefaultView;
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddPersonWindow window = new AddPersonWindow(ConnectDB);
            if (window.ShowDialog() == true)
            {
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(adapter);
                adapter.Update(dt);
            }
        }

        private void updateButton_Click(object sender, RoutedEventArgs e)
        {
            DataRowView newRow = (DataRowView)peopleDataGrid.SelectedItem;
            newRow.BeginEdit();
            ChangePerson window = new ChangePerson(newRow.Row);
            if (window.ShowDialog() == true)
            {
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(adapter);
                adapter.Update(dt);
            }
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            DataRowView newRow = (DataRowView)peopleDataGrid.SelectedItem;

            newRow.Row.Delete();
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(adapter);
            adapter.Update(dt);
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            //SqlDataAdapter adapter_ = new SqlDataAdapter("SELECT * FROM Work.dbo.View_Persons where " +
            //                                            $"Name like '%{TBSearch.Text}%' or Surname like '%{TBSearch.Text}%' " +
            //                                            $"or Secondname like '%{TBSearch.Text}%' " +
            //                                            $"or Department like '%{TBSearch.Text}%' or Sex like '%{TBSearch.Text}%'", connection);
            //DataTable table = new DataTable();
            //adapter_.Fill(table);
            //ConverterDepartments converter = new ConverterDepartments();
            //object s;
            //foreach(DataRow row in table.Rows)
            //{
            //    converter.ConvertBack(row["Department"], s, s, s);
                
            //}
            //peopleDataGrid.DataContext = table.DefaultView;
        }
    }
}
