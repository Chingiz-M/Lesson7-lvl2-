﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;


namespace SApp_WpfApp01
{
    /// <summary>
    /// Логика взаимодействия для ChangePerson.xaml
    /// </summary>
    public partial class ChangePerson : Window
    {
        public static Dictionary<int, string> dict = new Dictionary<int, string>();
        DataRow Row;
        public ChangePerson(DataRow ROW)
        {
            InitializeComponent();
            Row = ROW;
            SqlConnection connection = new SqlConnection(PersonWindow.ConnectDB);
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter("select ID, Department from Work.dbo.Departments", connection);
            adapter.Fill(dt);
            foreach (DataRow row in dt.Rows)
                if (!dict.ContainsKey(System.Convert.ToInt32(row.ItemArray[0])))
                    dict.Add(System.Convert.ToInt32(row.ItemArray[0]), row.ItemArray[1].ToString());
            Cb.ItemsSource = dict.Values;
            Cb.SelectedIndex = Convert.ToInt32(Row["Department"]) - 1;
            TbName.Text = Row["Name"].ToString();
            TbSurname.Text = Row["Surname"].ToString();
            TbSecondName.Text = Row["Secondname"].ToString();
            Dp.SelectedDate = Convert.ToDateTime(Row["Birthday"]);
            GenderControl.Gender = (Controls.Gender)Convert.ToUInt32(Row["Sex"]);
        }

        private void BtnChange_Click(object sender, RoutedEventArgs e)
        {
            int department = -1; // задаю департамент
            foreach (var pair in dict)
                if (pair.Value == Cb.SelectedItem.ToString())
                    department = pair.Key;

            Row["Name"] = TbName.Text;
            Row["Surname"] = TbSurname.Text;
            Row["Secondname"] = TbSecondName.Text;
            Row["Birthday"] = (DateTime)Dp.SelectedDate;
            Row["Department"] = department;
            Row["Sex"] = (int)GenderControl.Gender;

            this.DialogResult = true;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
