﻿using SApp_WpfApp01.Controls;
using System;

namespace SApp_WpfApp01
{
    public class Person
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Secondame { get; set; }
        public DateTime Birthday { get; set; }
        public Gender Gender { get; set; }
        public int Department { get; set; }

        public Person(string name, string surname, string secondname, DateTime birthday, Gender gender, int department)
        {
            Name = name;
            Surname = surname;
            Secondame = secondname;
            Birthday = birthday;
            Gender = gender;
            Department = department;
        }
    }
}
