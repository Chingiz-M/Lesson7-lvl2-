﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace SApp_WpfApp01
{
    class ConverterDepartments : IValueConverter
    {
        SqlConnection connection = new SqlConnection(PersonWindow.ConnectDB);
        Dictionary<int, string> dict = new Dictionary<int, string>();

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string result = null;
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter("select ID, Department from Work.dbo.Departments", connection);
            adapter.Fill(dt);
            foreach (DataRow row in dt.Rows)
                if(!dict.ContainsKey(System.Convert.ToInt32(row.ItemArray[0])))
                    dict.Add(System.Convert.ToInt32(row.ItemArray[0]), row.ItemArray[1].ToString());
            
            foreach (var pair in dict)
                if (pair.Key == (int)value)
                    result = pair.Value;
            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int result = 0;
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter("select ID, Department from Work.dbo.Departments", connection);
            adapter.Fill(dt);
            foreach (DataRow row in dt.Rows)
                if (!dict.ContainsKey(System.Convert.ToInt32(row.ItemArray[0])))
                    dict.Add(System.Convert.ToInt32(row.ItemArray[0]), row.ItemArray[1].ToString());

            foreach (var pair in dict)
                if (pair.Value == value.ToString())
                    result = pair.Key;
            return result;
        }
    }
}
