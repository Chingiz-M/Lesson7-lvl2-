﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;


namespace SApp_WpfApp01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class AddPersonWindow : Window
    {
        public static Dictionary<int, string> dict = new Dictionary<int, string>();

        public AddPersonWindow(string ConnectDB)
        {
            InitializeComponent();
            SqlConnection connection = new SqlConnection(ConnectDB);
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter("select ID, Department from Work.dbo.Departments", connection);
            adapter.Fill(dt);
            foreach (DataRow row in dt.Rows)
                if (!dict.ContainsKey(System.Convert.ToInt32(row.ItemArray[0])))
                    dict.Add(System.Convert.ToInt32(row.ItemArray[0]), row.ItemArray[1].ToString());
            Cb.ItemsSource = dict.Values;
            Cb.SelectedIndex = 1;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (TbName.Text != "" && TbSurname.Text != "" && TbSecondName.Text != "" && Dp.SelectedDate != null)
            {
                DataRow Row = PersonWindow.dt.NewRow(); 
                int department = -1; // задаю департамент
                foreach(var pair in dict)
                    if (pair.Value == Cb.SelectedItem.ToString())
                        department = pair.Key;

                Row["Name"] = TbName.Text;
                Row["Surname"] = TbSurname.Text;
                Row["Secondname"] = TbSecondName.Text;
                Row["Birthday"] = (DateTime)Dp.SelectedDate;
                Row["Department"] = department;
                Row["Sex"] = (int)GenderControl.Gender;

                PersonWindow.dt.Rows.Add(Row);
                this.DialogResult = true;
            }
            else
                MessageBox.Show(this, "Введите данные!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
